============
Contributing
============

Documentation for maintaining and contributing to this project.

gmxapi 0.1 Design notes
=======================

Open questions
==============

``output`` node
---------------

Placeholders for type and shape
-------------------------------

Python style preferences
------------------------

Subgraph
~~~~~~~~
