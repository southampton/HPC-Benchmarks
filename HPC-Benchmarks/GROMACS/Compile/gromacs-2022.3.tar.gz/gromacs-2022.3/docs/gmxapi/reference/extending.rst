=========
Extending
=========

Documentation for building code that uses or collaborates with GROMACS through gmxapi.

stub

.. discuss
    * concepts
    * protocols
    * pure Python
    * C++
